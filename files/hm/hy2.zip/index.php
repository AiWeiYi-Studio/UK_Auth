﻿

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>站长您好，反盗版系统检测到本站使用了盗版程序，如果需要继续使用请联系QQ：2874992246购买正版！使用正版程序，安全、稳定、声誉。</title>
	<style type="text/css">
		a,h1{
			text-align: center;
			color:red;
		}
	</style>
</head>
<body>
	<h1 style="margin-top:200px">站长您好，反盗版系统检测到本站使用了盗版程序</h1>
	<h1 style="margin-top:100px">如果需要继续使用请联系QQ：2874992246购买正版！</h1>
	<h1 style="margin-top:100px">使用正版程序，安全、稳定、声誉。</h1>
</body>
</html>